const Mutation = {

}

module.exports = Mutation;